package com.example.hp.myapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText mail,pw,cpw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mail=findViewById(R.id.mail);
        pw=findViewById(R.id.pw);
        cpw=findViewById(R.id.cpw);

    }
    public void signup(View view) {

        String email = mail.getText().toString();
        String password = pw.getText().toString();

        Toast.makeText(this, email, Toast.LENGTH_SHORT).show();
    }
}
